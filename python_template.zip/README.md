# README.md
# AI Program

This is a simple AI program that asks for the user's API key.

## How to Use

1. Clone the repository:
   
2. Navigate to the project directory:
   
3. Run the program:
   
4. Enter your API key when prompted.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.