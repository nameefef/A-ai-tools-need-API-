# DOCUMENTATION.md

# AI Program Documentation

## Overview
This is a simple AI program that prompts the user to enter their API key and displays it back to them. The program is designed to be easy to use and can be integrated into larger projects that require API key input.

## Installation

### Prerequisites
- Python 3.x installed on your system.

### Steps
1. Clone the repository:
   
2. Navigate to the project directory:
   
3. Install the required dependencies:
   

## Usage

### Running the Program
To run the program, use the following command:


### Entering the API Key
When prompted, enter your API key: