# main.py
def main():
    print("Welcome to the AI Program!")
    api_key = input("Please enter your API key: ")
    print(f"Thank you! Your API key is: {api_key}")

if __name__ == "__main__":
    main()